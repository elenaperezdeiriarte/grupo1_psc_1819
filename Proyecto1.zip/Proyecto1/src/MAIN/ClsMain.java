package MAIN;


import LPProyecto.JFrameMenuPrincipal;

public class ClsMain
{

	public static void main(String[] args)
	{
		JFrameMenuPrincipal objPrincipal = new JFrameMenuPrincipal();
		objPrincipal.setVisible(true);
	}
}
